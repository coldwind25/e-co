<?php

echo "sfsafsf";
echo "<br>";
echo 'aaaaaaa';
echo '<hr>';
echo 2423424242;


echo '<hr>';


//ใช้ var_dump เช็คชนิดข้อมูล
$mynumber = 100;
$mytxt ='สวัสดี';
$myprice = 223.323;

var_dump($mynumber);
echo "<br>";
var_dump($mytxt);
echo '<br>';
var_dump($myprice);
echo "<hr>";


//การเชื่อมตัวแปร
$title = "Mr.";
$name = 'John';
$lname = 'Snow';
echo $title.$name.' '.$lname;
echo '<hr>';

//การแสดงวันที่และเวลา
$mydate = date('Y-m-d H:i:s');
echo date('d/m/Y H:i:s',strtotime($mydate));
echo '<br>';
date_default_timezone_set('Asia/Bangkok');
$mydate2 = date('Y-m-d H:i:s');
echo date('d/m/Y H:i:s',strtotime($mydate2));

echo '<hr>';
//ทำ คศ. ให้เป็น พศ.
$y=date('Y');
$x=543;
echo $y+$x;
echo '<hr>';


//การใส่จุดทศนิยมและคอมมาให้กับราคาสินค้า
$price = 100798980; //ราคาสินค้า
$qty = 5; //จำนวนที่สั่งซื่อ
$total = $price * $qty;
echo 'Total = '.number_format($total,2);
echo '<hr>';


//การสร้าง session
session_start();
$_SESSION["admin"] = "member";
print_r($_SESSION);
echo "<br>";
$level = $_SESSION['admin'];
if($level=='admin'){
	echo 'R U Admin';
}else{
	echo 'Not Access';
}

//exit;
//การเคลียร์ session
session_unset();
session_destroy();

print_r($_SESSION);







?>