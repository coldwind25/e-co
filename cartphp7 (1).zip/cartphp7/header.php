<?php 
@session_start();
include('condb.php');
@$mem_id = $_SESSION['mem_id'];
@$querymember = "SELECT * FROM tbl_member WHERE mem_id=$mem_id"
or die ("Error : ".mysqli_error($querymember));
@$rsmember = mysqli_query($condb, $querymember);
@$row_buyer = mysqli_fetch_array($rsmember);
//print_r($row_buyer);
//print_r($_SESSION);
//echo @$_SESSION['mem_name'];


//qeury ประเภทสินค้าแสดงใน menu
$queryprdtype = "SELECT * FROM tbl_type" 
or die ("Error : ".mysqli_error($queryprdtype));
$rsprdtype = mysqli_query($condb, $queryprdtype);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>MyShop</title>
    <meta name="robots" content="index, follow">
    <meta name="keywords" content="ร้านค้าของฉัน" />
    <meta name="description" content="ร้านค้าของฉัน" />
    <meta content="th_TH" http-equiv="Content-Language" />
    <meta content="document" name="resource-type" />
    <meta content="global" name="distribution" />
    <meta content="ร้านค้าของฉัน" name="author" />
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
.zoom {
  padding: 0px;
  transition: transform .1s; /* Animation */
  margin: 0 auto;
}

.zoom:hover {
  transform: scale(1.2); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
}
</style>
  </head>
  <body>