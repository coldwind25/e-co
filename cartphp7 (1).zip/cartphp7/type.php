<?php
include('condb.php');
$t_id = $_GET['t_id'];
$queryproduct = "
SELECT p.*, t.t_name
FROM tbl_product as p
INNER JOIN tbl_type as t ON p.t_id=t.t_id
WHERE p.t_id=$t_id
"
or die ("Error : ".mysqli_error($queryproduct));
$rsproduct = mysqli_query($condb, $queryproduct);
$num=mysqli_num_rows($rsproduct);

// echo $num;

// exit;

//echo $queryproduct;
include 'header.php';
include 'banner.php';
include 'navbar.php';
?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h4> :: แสดงรายการสินค้าตามประเภท :: ประเภทสินค้าที่คุณเลือก : 
        <font color="blue"> <?php echo $_GET['name'];?>
        </font>
         </h4>
    </div>
    <?php 
    if($num > 0){
    foreach ($rsproduct as $row) { ?>
    <div class="col-sm-3 col-md-3">
      <div class="thumbnail">
        <img src="product_img/<?php echo $row['p_img'];?>" width="100%" class="zoom">
        <div class="caption">
          <h5><?php echo $row['p_name'];?></h5>
          <p>ราคา <?php echo number_format($row['p_price'],2);?> บาท</p>
          <p>
            <a href="detail.php?p_id=<?php echo $row['p_id'];?>&show=product-detail" class="btn btn-primary" role="button">รายละเอียด</a>

          <?php if($row['p_qty'] > 0){ ?>

            <a href="cart.php?act=add&p_id=<?php echo $row['p_id'];?>" class="btn btn-info" role="button">หยิบใส่ตะกร้า</a>

          <?php }else{

            echo '<button class="btn btn-danger" disabled> สินค้าหมด </button>';
          }
          ?>

          </p>
        </div>
      </div>
    </div>
    <?php
     }//close foeach
    }else{
      echo '<h4 align="center"> ไม่พบสินค้าที่คุณเลือก </h4>';
    } 
    ?>
  </div>
</div>

<?php include 'footer.php'; ?>