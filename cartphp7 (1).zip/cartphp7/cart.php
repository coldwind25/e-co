<?php
	@session_start();
	@$p_id = $_GET['p_id'];
	@$act = $_GET['act'];
	// print_r($_GET);
	// exit;
// echo '<pre>';
	//print_r($_SESSION['cart']);
	// echo '</pre>';

	// unset($_SESSION['shopping_cart']);
	// 	exit;

	if($act=='add' && !empty($p_id))
	{
		if(isset($_SESSION['cart'][$p_id]))
		{
			$_SESSION['cart'][$p_id]++;
		}
		else
		{
			$_SESSION['cart'][$p_id]=1;
		}
		header("Location: cart.php ");	
	}
	if($act=='remove' && !empty($p_id))  //ยกเลิกการสั่งซื้อ
	{
		unset($_SESSION['cart'][$p_id]);
	}
	if($act=='update')
	{
		$amount_array = $_POST['amount'];
		foreach($amount_array as $p_id=>$amount)
		{
			$_SESSION['cart'][$p_id]=$amount;
		}
	}
	include 'header.php';
	include 'navbar.php';
?>
<div class="container">
	<div class="row">
		<div class="col-xs-12 col-md-12">
			<form id="frmcart" name="frmcart" method="post" action="?act=update">
				<h4> ตะกร้าสินค้าของฉัน 
					<a href="index.php" class="btn btn-primary"> กลับหน้ารายการสินค้า </a>
				</h4>
				<table class="table table-bordered table-striped table-responsive">
					<tr>
						<td bgcolor="#EAEAEA" width="5%" class="hidden-xs" align="center">#</td>
						<td bgcolor="#EAEAEA" width="5%" class="hidden-xs">img</td>
						<td bgcolor="#EAEAEA" width="50%">ขื่อสินค้า</td>
						<td align="center" bgcolor="#EAEAEA" width="10%">ราคา</td>
						<td align="center" bgcolor="#EAEAEA" width="10%">จำนวน</td>
						<td align="center" bgcolor="#EAEAEA" width="10%">รวม(บาท)</td>
						<td align="center" bgcolor="#EAEAEA" width="5%">ลบ</td>
					</tr>
					<?php
					$total=0;
					if(!empty($_SESSION['cart']))
					{
						include("condb.php");
						foreach($_SESSION['cart'] as $p_id=>$qty)
						{
							$sql = "SELECT * FROM tbl_product WHERE p_id=$p_id";
							$query = mysqli_query($condb, $sql);
							$row = mysqli_fetch_array($query);
							$sum = $row['p_price'] * $qty;
							$total += $sum;
							$p_qty = $row["p_qty"];
							echo "<tr>";
								echo "<td class='hidden-xs' align='center'>" . @$i += 1 . "</td>";
								echo 
								"<td class='hidden-xs'>"
								."<img src='product_img/".$row['p_img']."' width='100%' class='hidden-xs'>"
								. "</td>";
								echo "<td>"
								. "<img src='product_img/".$row['p_img']."' width='100%' class='visible-xs'>"
								 
								. $row["p_name"]
								."<br>" 
								.'สต๊อก '
								.$p_qty
								.' รายการ'
								. "</td>";
								echo "<td align='right'>" .number_format($row["p_price"],2) . "</td>";
								echo "<td align='right'>";
									echo "<input type='number' name='amount[$p_id]' value='$qty' class='form-control' min='1' max='$p_qty' /></td>";
									echo "<td align='right'>".number_format($sum,2)."</td>";
									//remove product
									echo "<td align='center'>
										<a href='cart.php?p_id=$p_id&act=remove' class='btn btn-danger btn-xs'>ลบ</a>
									</td>";
								echo "</tr>";
							}
							echo "<tr>";
								echo "<td class='hidden-xs' colspan='5' bgcolor='#CEE7FF' align='center'><b>ราคารวม</b></td>";
								echo "<td class='visible-xs' colspan='4' bgcolor='#CEE7FF' align='center'><b>ราคารวม</b></td>";
								echo "<td align='right' bgcolor='#CEE7FF'>"."<b>".number_format($total,2)."</b>"."</td>";
								echo "<td align='left' bgcolor='#CEE7FF'></td>";
							echo "</tr>";
						}
						?>
						<tr>
								<td colspan="7" align="right">
							<?php if(!empty($_SESSION['cart'])) { ?>
								<input type="submit" name="button" id="button" value="ปรับปรุง"  class='btn btn-warning'/>
							<?php } ?>

								<?php if($act =='update'){ ?>
								<input type="button" name="Submit2" value="ขั้นตอนต่อไป" onclick="window.location='confirm.php';"  class='btn btn-success'/>
							<?php }else{} ?>

							</td>
						</tr>
					</table>
				</form>
			</div>
		</div>
	</div>
<div class="container hidden-xs">
  <div class="row">
  	<div class="col-xs-12 col-md-12">
  		<h4>::รายการสินค้า::</h4>
  	</div>
    <?php 
   $queryproduct = "
SELECT p.*, t.t_name
FROM tbl_product as p
INNER JOIN tbl_type as t ON p.t_id=t.t_id LIMIT 8"
or die ("Error : ".mysqli_error($queryproduct));
$rsproduct = mysqli_query($condb, $queryproduct);
foreach ($rsproduct as $rsprd2) { ?>
    <div class="col-xs-6 col-sm-3 col-md-3">
      <div class="thumbnail">
        <a href="detail.php?p_id=<?php echo $rsprd2['p_id'];?>&show=product-detail">
          <img src="product_img/<?php echo $rsprd2['p_img'];?>" width="100%" class="zoom">
        </a>
        <div class="caption">
          <h5><?php echo $rsprd2['p_name'];?></h5>
          <p>ราคา <?php echo number_format($rsprd2['p_price'],2);?> บาท</p>
          <p>
            <a href="detail.php?p_id=<?php echo $rsprd2['p_id'];?>&show=product-detail" class="btn btn-primary hidden-xs" role="button">รายละเอียด</a>
            <?php if($rsprd2['p_qty'] > 0){ ?>
            <a href="cart.php?act=add&p_id=<?php echo $rsprd2['p_id'];?>" class="btn btn-info" role="button">หยิบใส่ตะกร้า</a>
            <?php }else{
            echo '<button class="btn btn-danger" disabled> สินค้าหมด </button>';
            }
            ?>
          </p>
        </div>
      </div>
    </div>
    <?php } ?>
  </div>
</div>
	<?php include 'footer.php';?>