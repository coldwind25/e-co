<?php
include('condb.php');
include 'header.php';
include 'banner.php';
include 'navbar.php';
?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h3>วิธีสั่งซื้อ</h3>
       <pre>
       	วิธีสั่งซื้อ
       	วิธีสั่งซื้อ
       	วิธีสั่งซื้อ
       	วิธีสั่งซื้อ
       	วิธีสั่งซื้อ
       	วิธีสั่งซื้อ
       	วิธีสั่งซื้อ
        วิธีสั่งซื้อ
        วิธีสั่งซื้อ
        วิธีสั่งซื้อ
        วิธีสั่งซื้อ
        วิธีสั่งซื้อ
       </pre>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>