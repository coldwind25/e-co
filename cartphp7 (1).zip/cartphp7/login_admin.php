<?php
include('condb.php');
include 'header.php';
include 'banner.php';
include 'navbar.php';
?>
<div class="container">
  <div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-4">
      <h4>Login Admin</h4>
      <form name="frmlogin"  method="post" action="loginadmin.php" class="form-horizontal">
        <p> </p>
        <p> ชื่อผู้ใช้ :
          <input type="text" id="Username" required name="admin_user" placeholder="Username" class="form-control">
        </p>
        <p>รหัสผ่าน :
          <input type="password" id="Password"required name="admin_pass" placeholder="Password" class="form-control">
        </p>
        <p>
          <button type="submit" class="btn btn-primary">Login</button>
          &nbsp;&nbsp;
          <button type="reset" class="btn btn-danger">Reset</button>
          <br>
        </p>
      </form>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>