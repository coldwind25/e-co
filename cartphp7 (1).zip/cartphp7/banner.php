<div class="container">
	<div class="row">
		<div class="col-md-12">
			<img src="img/b.png" width="100%">
		</div>
	</div>
</div>