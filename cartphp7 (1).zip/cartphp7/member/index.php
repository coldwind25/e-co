<?php 
include 'header.php';
include 'menu_left.php';
include 'body.php';
include 'footer.php';
?>
