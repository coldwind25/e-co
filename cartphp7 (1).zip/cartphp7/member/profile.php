<?php 
include 'header.php';
include 'menu_left.php';
?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
    แก้ไขโปรไฟล์
    </h1>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-7">
        <div class="box">
          <!-- /.box-header -->
          <div class="box-body">
            <form  name="register" action="member_form_edit_db.php" method="POST" id="register" class="form-horizontal" enctype="multipart/form-data">
              <div class="form-group">
                <div class="col-sm-2">  </div>
                <div class="col-sm-5" align="left">
                  <font color="red"> *กรุณากรอกข้อมูลให้ครบทุกช่อง </font>
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-2" align="right"> Username : </div>
                <div class="col-sm-5" align="left">
                  <input  name="mem_username" type="text" required class="form-control" id="mem_username" placeholder="username" pattern="^[a-zA-Z0-9]+$" title="ภาษาอังกฤษหรือตัวเลขเท่านั้น" minlength="2" value="<?php echo $rowm['mem_username'];?>"  disabled />
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-2" align="right"> ชื่อ-สกุล : </div>
                <div class="col-sm-7" align="left">
                  <input  name="mem_name" type="text" required class="form-control" id="mem_name" placeholder="ชื่อ-สกุล" value="<?php echo $rowm['mem_name'];?>" />
                </div>
              </div>
              
              
              <div class="form-group">
                <div class="col-sm-2" align="right"> อีเมล์ : </div>
                <div class="col-sm-6" align="left">
                  <input  name="mem_email" type="email" class="form-control" id="mem_email"   placeholder="อีเมล์" value="<?php echo $rowm['mem_email'];?>"/>
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-2" align="right"> เบอร์โทร : </div>
                <div class="col-sm-6" align="left">
                  <input  name="mem_tel" type="text" class="form-control" id="mem_tel"  placeholder="เบอร์โทร" value="<?php echo $rowm['mem_tel'];?>" />
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-2" align="right"> ที่อยู่ : </div>
                <div class="col-sm-6" align="left">
                  <textarea name="mem_address" class="form-control" id="mem_address" required><?php echo $rowm['mem_address'];?></textarea>
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-2" align="right"> img : </div>
                <div class="col-sm-6" align="left">
                  <img src="../mem_img/<?php echo $rowm['mem_img'];?>" width="200px">
                  <br><br>
                  เลือกภาพใหม่
                  <br><br>
                  <input type="file" name="mem_img"  accept="image/*" class="form-control">
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-2"> </div>
                <div class="col-sm-6">
                  <input type="hidden" name="mem_id" value="<?php echo $rowm['mem_id'];?>">
                  <input type="hidden" name="mem_img2" value="<?php echo $rowm['mem_img'];?>">
                  <button type="submit" class="btn btn-primary" id="btn">  บันทึก   </button>
                </div>
                
              </div>
            </form>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->

<?php include 'footer.php';?>







