
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

<?php 
$queryorder = "SELECT * FROM tbl_order WHERE mem_id=$mem_id" 
or die ("Error : ".mysqli_error($queryorder));
$rsorder = mysqli_query($condb, $queryorder);

//echo $queryorder;
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
 ประวัติการสั่งซื้อ
<a href="../index.php" class="btn btn-primary"> เลือกสินค้า </a>
  </h1>
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-xs-10">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">รายการสั่งซื้อ</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
              <tr class="danger">
                <th width="5%">#</th>
                <th width="15%">status</th>
                <th width="15%">date</th>
                <th width="5%">slip</th>
                <th width="10%">EMS</th>
                <th width="5%">view</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rsorder as $row) { ?>
              <tr>
                <td><?php echo $row['order_id'];?></td>
                <td>
                  <?php 
                  $status = $row['order_status'];
                  include('status.php');
                  ?>
                    
                  </td>
                <td><?php echo $row['order_date'];?></td>
                <td>
                  <?php if($row['pay_slip'] !='') {;?>
                    <a href="../slip_img/<?php echo $row['pay_slip'];?>" target="_blank">
                  <img src="../slip_img/<?php echo $row['pay_slip'];?>" width="70%">
                </a>
                <?php }?>
                  </td>
                <td><?php echo $row['postcode'];?></td>
                <td>
                  <?php  if($status==1) { ?>

                  <a href="../payment.php?order_id=<?php echo $row['order_id'];?>" class="btn btn-danger btn-xs" target="_blank"> ชำระเงิน </a>

                <?php  } elseif ($status==2) { ?>

                   <a href="../orderdetail.php?order_id=<?php echo $row['order_id'];?>" class="btn btn-info btn-xs" target="_blank"> เปิดดู </a>

             <?php  } elseif ($status==3) { ?>

                   <a href="../orderdetail.php?order_id=<?php echo $row['order_id'];?>&act=ems" class="btn btn-success btn-xs" target="_blank"> เช็ค EMS  </a>
               <?php   } ?>

                </td>
              </tr>  
              <?php } ?> 
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->