<meta charset="UTF-8" />
<?php
include('../condb.php');


// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
// exit;


	$date1 = date("Ymd_His");
	//สร้างตัวแปรสุ่มตัวเลขเพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลดไม่ให้ชื่อไฟล์ซ้ำกัน
	$numrand = (mt_rand());


$mem_id = mysqli_real_escape_string($condb,$_POST['mem_id']);
$mem_img2 = mysqli_real_escape_string($condb,$_POST['mem_img2']); 
$mem_name = mysqli_real_escape_string($condb,$_POST['mem_name']);
$mem_email = mysqli_real_escape_string($condb,$_POST['mem_email']);
$mem_tel = mysqli_real_escape_string($condb,$_POST['mem_tel']);
$mem_address = mysqli_real_escape_string($condb,$_POST['mem_address']);


//upload ภาพ 
	$upload=$_FILES['mem_img']['name'];
	if($upload !='') { 
 
	//โฟลเดอร์ที่เก็บไฟล์
	$path="../mem_img/";
	//ตัวขื่อกับนามสกุลภาพออกจากกัน
	$type = strrchr($_FILES['mem_img']['name'],".");
	//ตั้งชื่อไฟล์ใหม่เป็น สุ่มตัวเลข+วันที่
	$newname ='member'.$numrand.$date1.$type;
	$path_copy=$path.$newname;
	$path_link="../mem_img/".$newname;
	//คัดลอกไฟล์ไปยังโฟลเดอร์
	move_uploaded_file($_FILES['mem_img']['tmp_name'],$path_copy);  
		
	}else{
		$newname = $mem_img2;
	}



$sql =" UPDATE  tbl_member SET 
		mem_name='$mem_name',
		mem_email='$mem_email',
		mem_tel='$mem_tel',
		mem_address='$mem_address',
		mem_img='$newname'

		WHERE mem_id=$mem_id		
 ";
		
		$result = mysqli_query($condb, $sql) or die("Error in query : $sql" .mysqli_error());

// echo $sql;
// exit;
		mysqli_close($condb);
		
		if($result){
			echo "<script>";
			echo "alert('แก้ไขโปรไฟล์เรียบร้อยแล้ว');";
			echo "window.location ='profile.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='profile.php'; ";
			echo "</script>";
		}
		
?>