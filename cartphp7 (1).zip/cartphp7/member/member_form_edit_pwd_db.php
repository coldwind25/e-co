<meta charset="UTF-8" />
<?php
include('../condb.php');


// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
// exit;


	$date1 = date("Ymd_His");
	//สร้างตัวแปรสุ่มตัวเลขเพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลดไม่ให้ชื่อไฟล์ซ้ำกัน
	$numrand = (mt_rand());

$mem_id = mysqli_real_escape_string($condb,$_POST['mem_id']);
$mem_password = mysqli_real_escape_string($condb,sha1($_POST['mem_password']));




$sql =" UPDATE  tbl_member SET 
		mem_password='$mem_password'
		WHERE mem_id=$mem_id		
 ";
		
		$result = mysqli_query($condb, $sql) or die("Error in query : $sql" .mysqli_error());

// echo $sql;
// exit;
		mysqli_close($condb);
		
		if($result){
			echo "<script>";
			echo "alert('แก้ไขรหัสผ่านเรียบร้อยแล้ว');";
			echo "window.location ='index.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='index.php'; ";
			echo "</script>";
		}
		
?>