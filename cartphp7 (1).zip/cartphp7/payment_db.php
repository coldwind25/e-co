<?php
include 'condb.php';
//print_r($_POST);
$b_id = mysqli_real_escape_string($condb,$_POST['b_id']);
$pay_date = mysqli_real_escape_string($condb,$_POST['pay_date']);
$pay_amount = mysqli_real_escape_string($condb,$_POST['pay_amount']);
$order_id = mysqli_real_escape_string($condb,$_POST['order_id']);
$order_status =2;

//สร้างตัวแปรวันที่เพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลด
	$date1 = date("Ymd_His");
	//สร้างตัวแปรสุ่มตัวเลขเพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลดไม่ให้ชื่อไฟล์ซ้ำกัน
	$numrand = (mt_rand());

$pay_slip = (isset($_POST['pay_slip']) ? $_POST['pay_slip'] : '');
$upload=$_FILES['pay_slip'];
	if($upload !='') { 
	//โฟลเดอร์ที่เก็บไฟล์
	$path="slip_img/";
	//ตัวขื่อกับนามสกุลภาพออกจากกัน
	$type = strrchr($_FILES['pay_slip']['name'],".");
	//ตั้งชื่อไฟล์ใหม่เป็น สุ่มตัวเลข+วันที่
	$newname ='product'.$numrand.$date1.$type;
 
	$path_copy=$path.$newname;
	$path_link="slip_img/".$newname;
	//คัดลอกไฟล์ไปยังโฟลเดอร์
	move_uploaded_file($_FILES['pay_slip']['tmp_name'],$path_copy);  
		
	}else{}


 
$sql ="UPDATE  tbl_order SET 
		
		b_id='$b_id',
		pay_date='$pay_date',
		pay_amount='$pay_amount',
		order_status='$order_status',
		pay_slip='$newname'

		WHERE order_id=$order_id 
	
		 ";
		
		$result = mysqli_query($condb, $sql) or die("Error in query : $sql" .mysqli_error());
 
// echo $sql;
// exit();

		mysqli_close($condb);
		
		if($result){
			echo "<script>";
			//echo "alert('แก้ไขสินค้าเรียบร้อยแล้ว');";
			echo "window.location ='member/'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='member/'; ";
			echo "</script>";
		}
		


?>