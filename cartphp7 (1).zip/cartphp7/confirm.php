<?php
include 'header.php';
include 'navbar.php';
// echo '<pre>';
//         print_r($_SESSION['cart']);
// echo '</pre>';

//echo 'mid = '.$mem_id;

if($mem_id ==''){ //ถ้าไม่มีการ login
  //header("Location: login.php ");
      echo "<script>";
      echo "alert('กรุณา Login  ก่อนทำการสั่งซื้อสินค้า');";
      echo "window.location ='login.php'; ";
      echo "</script>";
}


?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h4>Confirm Cart</h4>
      <form id="frmcart" name="frmcart" method="post" action="saveorder.php">
        <table class="table table-bordered table-striped">
          <tr>
            <td bgcolor="#EAEAEA" width="5%" class="hidden-xs" align="center">#</td>
            <td bgcolor="#EAEAEA" width="5%" class="hidden-xs">img</td>
            <td bgcolor="#EAEAEA" width="50%">ขื่อสินค้า</td>
            <td align="center" bgcolor="#EAEAEA" width="10%">ราคา</td>
            <td align="center" bgcolor="#EAEAEA" width="10%">จำนวน</td>
            <td align="center" bgcolor="#EAEAEA" width="10%">รวม(บาท)</td>
          </tr>
          <?php
          $total=0;
          if(!empty($_SESSION['cart']))
          {
          include("condb.php");
          foreach($_SESSION['cart'] as $p_id=>$qty)
          {
          $sql = "SELECT * FROM tbl_product WHERE p_id=$p_id";
          $query = mysqli_query($condb, $sql);
          $row = mysqli_fetch_array($query);
          $sum = $row['p_price'] * $qty; //
          $total += $sum;
          echo "<tr>";
            echo "<td class='hidden-xs' align='center'>" . @$i += 1 . "</td>";
            echo "<td class='hidden-xs'>"
              . "<img src='product_img/".$row['p_img']."' width='100%'>"
            . "</td>";
            echo "<td>" 
            . "<img src='product_img/".$row['p_img']."' width='100%' class='visible-xs'>"
            . $row["p_name"] 
            . "</td>";
            echo "<td align='right'>" .number_format($row["p_price"],2) . "</td>";
            echo "<td align='right'>";
              echo "<input type='number' name='amount[$p_id]' value='$qty' class='form-control' readonly /></td>";
              echo "<td align='right'>".number_format($sum,2)."</td>";
              
            echo "</tr>";
            }
            echo "<tr>";
              echo "<td class='visible-xs' colspan='2' bgcolor='#CEE7FF' align='center'><b>ราคารวม</b></td>";
              echo "<td class='hidden-xs' colspan='4' bgcolor='#CEE7FF' align='center'><b>ราคารวม</b></td>";
              echo "<td align='right' bgcolor='#CEE7FF'>"."<b>".number_format($total,2)."</b>"."</td>";
              echo "<td align='left' bgcolor='#CEE7FF'></td>";
            echo "</tr>";
            }
            ?>
          </table>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-md-4"></div>
        <div class="col-md-5" style="background-color:#f4f4f4">
          <h3 align="center" style="color:green">
          <span class="glyphicon glyphicon-shopping-cart"> </span>
          ที่อยู่ในการจัดส่งสินค้า  </h3>
          <div class="form-group">
            <div class="col-sm-12">
              <input type="text"  name="name" value="<?php echo $row_buyer['mem_name']; ?>" class="form-control" required placeholder="ชื่อ-สกุล" disabled />
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-12">
              <textarea name="address" class="form-control"  rows="3"  disabled placeholder="ที่อยู่ในการส่งสินค้า"><?php echo $row_buyer['mem_address']; ?></textarea>
            </div>
            
          </div>
          <div class="form-group">
            <div class="col-sm-12">
              <input type="text"  name="phone" value="<?php echo $row_buyer['mem_tel']; ?>" class="form-control" disabled placeholder="เบอร์โทรศัพท์" />
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-12">
              <input type="email"  name="email" class="form-control" value="<?php echo $row_buyer['mem_email']; ?>" disabled placeholder="อีเมล์" />
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-12" align="center">
              <input name="mem_id" type="hidden" id="mem_id" value="<?php echo $row_buyer['mem_id']; ?>">
              <button type="submit" class="btn btn-primary" id="btn">
              ยืนยันสั่งซื้อ </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
  <?php include 'footer.php';?>