<meta charset=utf-8>
<?php
	session_start();
    include("condb.php");


  // echo '<pre>';
  // print_r($_SESSION['cart']);
  // echo '</pre>'; 


  // echo '<pre>';
  // print_r($_POST);
  // echo '</pre>';

  // exit;

	$mem_id = $_POST["mem_id"]; //
	$order_status = 1;
	$pay_slip ='';
	$b_id = 0;
	$pay_date = '0000-00-00';
	$pay_amount = 0;
	$postcode = '';
	$order_date = Date("Y-m-d G:i:s");
	//บันทึกการสั่งซื้อลงใน order_detail
	mysqli_query($condb, "BEGIN"); 

	$sql1	= "INSERT INTO tbl_order VALUES
	(
	null,
	'$mem_id',
	'$order_status',
	'$pay_slip',
	'$b_id',
	'$pay_date',
	'$pay_amount',
	'$postcode',
	'$order_date'
	)";
	$query1	= mysqli_query($condb, $sql1) or die("Error : $sql1". mysqli_error());




	//ฟังก์ชั่น MAX() จะคืนค่าที่มากที่สุดในคอลัมน์ที่ระบุ ออกมา หรือจะพูดง่ายๆก็ว่า ใช้สำหรับหาค่าที่มากที่สุด นั่นเอง.
	$sql2 = "
	SELECT max(order_id) as order_id 
	FROM tbl_order 
	WHERE mem_id='$mem_id'
	";
	$query2	= mysqli_query($condb, $sql2) or die("Error : $sql2". mysqli_error());
	$row = mysqli_fetch_array($query2);
	$order_id = $row["order_id"];
//PHP foreach() เป็นคำสั่งเพื่อนำข้อมูลออกมาจากตัวแปลที่เป็นประเภท array โดยสามารถเรียกค่าได้ทั้ง $key และ $value ของ array
	foreach($_SESSION['cart'] as $p_id=>$qty)
	{
		$sql3	= "SELECT * FROM tbl_product WHERE p_id=$p_id";
		$query3	= mysqli_query($condb, $sql3) or die("Error : $sql3". mysqli_error());
		$row3	= mysqli_fetch_array($query3);
		$totalp	= $row3['p_price']*$qty;
		$count=mysqli_num_rows($query3); //นับจำนวนรายการสินค้าที่มีในตะกร้า

		
		$sql4	= "INSERT INTO tbl_order_detail VALUES
		(null, '$order_id', '$p_id', '$qty', '$totalp')";
		$query4	= mysqli_query($condb, $sql4) or die("Error : $sql4". mysqli_error());

				  //ตัดสต๊อก
				  for($i=0; $i<$count; $i++){
							  $have =  $row3['p_qty'];//จำนวนที่มีในสต๊อก
							  
							  $stc = $have - $qty; //จำนวนคงเหลือ
							  
							  $sql9 = "
							  UPDATE tbl_product SET  
							  p_qty=$stc
							  WHERE  p_id=$p_id ";
							  $query9 = mysqli_query($condb, $sql9);  
				  }



	}
	

	if($query1 && $query4){
		mysqli_query($condb, "COMMIT");
		$msg = "บันทึกข้อมูลเรียบร้อยแล้ว ";
		foreach($_SESSION['cart'] as $p_id)
		{	
			//unset($_SESSION['cart'][$p_id]);
			unset($_SESSION['cart']);
		}
	}
	else{
		mysqli_query($condb, "ROLLBACK");  
		$msg = "บันทึกข้อมูลไม่สำเร็จ กรุณาติดต่อเจ้าหน้าที่ค่ะ ";	
	}

// echo $msg;

// exit;

?>
<script type="text/javascript">
	alert("<?php echo $msg;?>");
	window.location ='payment.php?order_id=<?php echo $order_id;?>';
</script>







