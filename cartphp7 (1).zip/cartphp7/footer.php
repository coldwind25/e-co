<div class="container">
	<div class="row">
		<div class="col-md-12">
			<p align="center" style="margin-top: 100px; margin-bottom: 0px; background-color: #e0dcdc;">
				<br><br>
				Copyright © 2019  All rights reserved. หมายเลขทะเบียนการค้าอิเล็กทรอนิกส์ : xxxxxxxxxxx
				<br>
				ที่อยู่ 99/9999 วงเวียนใหญ่ กทม. 10700
				<br>
				โทร. 02-xxx-xxxx, email : xxxxxxx@gmail.com, lineid : xxxxxx
				<br>
				<a href="login_admin.php"> admin login </a>
				<br><br>
				<br><br>
			</p>
		</div>
	</div>
</div>
</body>
</html>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="js/bootstrap.min.js"></script>