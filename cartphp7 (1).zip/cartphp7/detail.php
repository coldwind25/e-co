<?php
include('condb.php');
$p_id = mysqli_real_escape_string($condb,$_GET['p_id']);
$queryproduct = "
SELECT *
FROM tbl_product
WHERE p_id=$p_id
"
or die ("Error : ".mysqli_error($queryproduct));
$rsproduct = mysqli_query($condb, $queryproduct);
$rs = mysqli_fetch_array($rsproduct);


// print_r($rs);
// exit;

//echo $queryproduct;
include 'header2.php';
include 'banner.php';
include 'navbar.php';
?>
<div class="container">
  <div class="row">
    <div class="col-xs-12 col-md-4">
      <img src="product_img/<?php echo $rs['p_img'];?>" width="100%">
    </div>
    <div class="col-xs-12 col-md-8"> 
      <h2>
        <?php echo $rs['p_name'];?>
          
           <?php if($rs['p_qty'] > 0){ ?>

            <a href="cart.php?act=add&p_id=<?php echo $rs['p_id'];?>" class="btn btn-info" role="button">หยิบใส่ตะกร้า</a>

          <?php }else{

            echo '<button class="btn btn-danger" disabled> สินค้าหมด </button>';
          }
          ?>



        </h2>

          <h4>
            ราคา <?php echo number_format($rs['p_price'],2);?> บาท
            <br><br>
            สินค้าคงเหลือ  <?php echo $rs['p_qty'];?>  รายการ
          </h4> 

          <p><?php echo $rs['p_detial'];?>  </p>
    </div>
  </div>
</div>
<?php include 'footer.php'; ?>





