<meta charset=utf-8>
<?php 
include('../condb.php');
// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
// exit;

//ประกาศตัวแปรรับค่าจากฟอร์ม 
$t_id = $_GET['t_id'];
		//นำเข้าตารางเก็บข้อมู
$sql ="DELETE FROM tbl_type WHERE t_id=$t_id ";
$result = mysqli_query($condb, $sql) or die("Error : $sql". mysqli_error());

// echo $sql;
// exit;

mysqli_close($condb);

if($result){
			echo "<script>";
			//echo "alert('เพิ่มข้อมูลเรียบร้อยแล้ว');";
			echo "window.location ='prdtype.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='prdtype.php'; ";
			echo "</script>";
		}


?>