<meta charset=utf-8>
<?php 
include('../condb.php');
// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
// exit;

//ประกาศตัวแปรรับค่าจากฟอร์ม 
$b_id = mysqli_real_escape_string($condb,$_GET['b_id']);

		//นำเข้าตารางเก็บข้อมูล
		$sql ="DELETE FROM  tbl_bank WHERE b_id = $b_id ";

		$result = mysqli_query($condb, $sql) or die("Error : $sql". mysqli_error());


// echo $sql;
// exit;

mysqli_close($condb);

if($result){
			echo "<script>";
			//echo "alert('แก้ไขข้อมูล bank เรียบร้อยแล้ว');";
			echo "window.location ='bank.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='bank.php'; ";
			echo "</script>";
		}


?>