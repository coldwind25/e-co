<?php 
include 'header.php';
include 'menu_left.php';

@$act = $_GET['act'];



//include 'product_form_add.php';


if($act == 'add'){
  include 'product_form_add.php';
}elseif($act == 'edit'){
  include 'product_form_edit.php';
}else{
  include 'product_list.php';
}




include 'footer.php';
?>
