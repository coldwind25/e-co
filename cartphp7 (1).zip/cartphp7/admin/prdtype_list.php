<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<?php 
$queryprdtype = "SELECT * FROM tbl_type" 
or die ("Error : ".mysqli_error($queryprdtype));
$rsprdtype = mysqli_query($condb, $queryprdtype);
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
  จัดการประเภทสินค้า
  <a href="prdtype.php?act=add" class="btn btn-primary"> +เพิ่มข้อมูล </a>
<!--   <small>advanced tables</small> -->
  </h1>
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">รายการ prdtype </h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
              <tr class="danger">
                <th width="5%">ID</th>
                <th width="60%">NAME</th>
                <th width="5%">แก้ไข</th>
                <th width="5%">ลบ</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rsprdtype as $row) { ?>
              <tr>
                <td><?php echo $row['t_id'];?></td>
                <td><?php echo $row['t_name'];?></td>
                <td align="center">
                  <a href="prdtype.php?act=edit&t_id=<?php echo $row['t_id'];?>" class="btn btn-warning btn-xs"> แก้ไข </a></td>
                <td align="center">
                  <a href="prdtype_del.php?t_id=<?php echo $row['t_id'];?>" class="btn btn-danger btn-xs" onclick="return confirm('ยืนยันการลบข้อมูล');"> ลบ </a></td>
              </tr>
            <?php } ?>
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->