<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<?php 
$queryadmin = "SELECT * FROM tbl_admin" 
or die ("Error : ".mysqli_error($queryadmin));
$rsadmin = mysqli_query($condb, $queryadmin);
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
  จัดการผู้ดูแลระบบ
  <a href="admin.php?act=add" class="btn btn-primary"> +เพิ่มข้อมูล </a>
<!--   <small>advanced tables</small> -->
  </h1>
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">รายการ Admin </h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
              <tr class="danger">
                <th width="5%">ID</th>
                <th width="60%">NAME</th>
                <th width="10%">USER</th>
                <th width="5%">แก้รหัส</th>
                <th width="5%">แก้ไข</th>
                <th width="5%">ลบ</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rsadmin as $row) { ?>
              <tr>
                <td><?php echo $row['admin_id'];?></td>
                <td><?php echo $row['admin_name'];?></td>
                <td><?php echo $row['admin_user'];?></td>
                <td align="center">
                  <a href="admin.php?act=pwd&admin_id=<?php echo $row['admin_id'];?>" class="btn btn-info btn-xs"> แก้รหัส </a></td>
                <td align="center">
                  <a href="admin.php?act=edit&admin_id=<?php echo $row['admin_id'];?>" class="btn btn-warning btn-xs"> แก้ไข </a></td>
                <td align="center">
                  <a href="admin_del.php?admin_id=<?php echo $row['admin_id'];?>" class="btn btn-danger btn-xs" onclick="return confirm('ยืนยันการลบข้อมูล');"> ลบ </a></td>
              </tr>
            <?php } ?>
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->