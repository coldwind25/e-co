
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

<?php 
$queryorder = "
SELECT p.p_name, SUM(o.p_c_qty) AS p_c_qty 
FROM tbl_order_detail as o 
INNER JOIN tbl_product as p ON p.p_id=o.p_id
INNER JOIN tbl_order as r ON o.order_id = r.order_id
WHERE r.order_status > 1
GROUP BY o.p_id 
ORDER BY  p_c_qty DESC 
LIMIT 5" 
or die ("Error : ".mysqli_error($queryorder));
$rsorder = mysqli_query($condb, $queryorder);

//echo $queryorder;
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
 รายงานสินค้าขายดี 5 อันดับ (เรียงตามจำนวนที่ขายได้)
  <button class="btn btn-primary" onclick="window.print();">พิมพ์รายงาน</button>
  </h1>
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-xs-5">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">รายงานสินค้าขายดี 5 อันดับ</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <table  class="table table-bordered table-striped">
            <thead>
              <tr class="danger">
                <th width="5%">#</th>
                <th width="50%">ชื่อสินค้า</th>
                <th width="10%"><center>จำนวน</center></th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rsorder as $row) { ?>
              <tr>
                <td><?php echo @$i += 1 ;?></td>
                <td><?php echo $row['p_name'];?></td>
                <td align="center"><?php echo $row['p_c_qty'];?> </td>
              </tr>  
              <?php  } ?> 
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->