<?php 
include 'header.php';
include 'menu_left.php';

@$act = $_GET['act'];


if($act == 'add'){
  include 'member_form_add.php';
}elseif($act == 'edit'){
  include 'member_form_edit.php';
}elseif($act == 'pwd'){
  include 'member_form_edit_pwd.php';
}else{
  include 'member_list.php';
}




include 'footer.php';
?>
