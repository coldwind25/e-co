<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <?php
  $admin_id = mysqli_real_escape_string($condb,$_GET['admin_id']);
  $queryadmin = "SELECT * FROM tbl_admin WHERE admin_id=$admin_id"
  or die ("Error : ".mysqli_error($queryadmin));
  $rsadmin = mysqli_query($condb, $queryadmin);
  $row = mysqli_fetch_array($rsadmin);
  //print_r($row);
  ?>
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
    ฟอร์มแก้ไขรหัสผ่านผู้ดูแลระบบ
    </h1>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-7">
        <div class="box">
          <!-- /.box-header -->
          <div class="box-body">
            <form action="admin_form_edit_pwd_db.php" method="post" class="form-horizontal" enctype="multipart/form-data">
              <div class="form-group">
                <div class="col-sm-2 control-label">
                  Username
                </div>
                <div class="col-sm-3">
                  <input type="text" name="admin_user" class="form-control" required minlength="3" placeholder="Username" pattern="[a-zA-Z0-9]+" value="<?php echo $row['admin_user'];?>" disabled>
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-2 control-label">
                  Password
                </div>
                <div class="col-sm-3">
                  <input type="text" name="admin_pass" class="form-control" required minlength="3" placeholder="password" pattern="[a-zA-Z0-9]+">
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-2 control-label">
                </div>
                <div class="col-sm-4">
                  <input type="hidden"  name="admin_id" value="<?php echo $row['admin_id'];?>" >
                  <button type="submit" class="btn btn-primary"> บันทึก </button>
                </div>
              </div>
            </form>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->