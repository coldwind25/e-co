<meta charset=utf-8>
<?php 
include('../condb.php');
// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
// exit;

//ประกาศตัวแปรรับค่าจากฟอร์ม 
$t_name = mysqli_real_escape_string($condb,$_POST['t_name']);
$t_id = mysqli_real_escape_string($condb,$_POST['t_id']);

		//นำเข้าตารางเก็บข้อมูล
		$sql ="UPDATE tbl_type SET
		t_name='$t_name'
		WHERE t_id=$t_id
		";
		$result = mysqli_query($condb, $sql) or die("Error : $sql". mysqli_error());



// echo $sql;
// exit;

mysqli_close($condb);

if($result){
			echo "<script>";
			echo "alert('แก้ไขข้อมูลเรียบร้อยแล้ว');";
			echo "window.location ='prdtype.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='prdtype.php'; ";
			echo "</script>";
		}


?>