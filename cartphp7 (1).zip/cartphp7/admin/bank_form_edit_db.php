<meta charset="UTF-8" />
<?php
include('../condb.php');
	//สร้างตัวแปรวันที่เพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลด
	$date1 = date("Ymd_His");
	//สร้างตัวแปรสุ่มตัวเลขเพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลดไม่ให้ชื่อไฟล์ซ้ำกัน
	$numrand = (mt_rand());
 

$b_name = mysqli_real_escape_string($condb,$_POST['b_name']);
$b_number = mysqli_real_escape_string($condb,$_POST['b_number']);
$b_type = mysqli_real_escape_string($condb,$_POST['b_type']);
$bn_name = mysqli_real_escape_string($condb,$_POST['bn_name']);
$b_owner = mysqli_real_escape_string($condb,$_POST['b_owner']);
$b_id = mysqli_real_escape_string($condb,$_POST['b_id']);
$b_logo2 = mysqli_real_escape_string($condb,$_POST['b_logo2']);

$b_logo = (isset($_POST['b_logo']) ? $_POST['b_logo'] : '');
$upload=$_FILES['b_logo']['name'];
	if($upload !='') { 
	//โฟลเดอร์ที่เก็บไฟล์
	$path="../bank_logo/";
	//ตัวขื่อกับนามสกุลภาพออกจากกัน
	$type = strrchr($_FILES['b_logo']['name'],".");
	//ตั้งชื่อไฟล์ใหม่เป็น สุ่มตัวเลข+วันที่
	$newname ='bank'.$numrand.$date1.$type;
 
	$path_copy=$path.$newname;
	$path_link="../bank_logo/".$newname;
	//คัดลอกไฟล์ไปยังโฟลเดอร์
	move_uploaded_file($_FILES['b_logo']['tmp_name'],$path_copy);  
		
	}else{
		$newname=$b_logo2;
	}

$sql ="UPDATE  tbl_bank SET 
		b_name='$b_name',
		b_number='$b_number',
		b_type='$b_type',
		bn_name='$bn_name',
		b_owner='$b_owner',
		b_logo='$newname'
		WHERE b_id = $b_id
		";
		
		$result = mysqli_query($condb, $sql) or die("Error in query : $sql" .mysqli_error());
 
		mysqli_close($condb);
		
		if($result){
			echo "<script>";
			echo "alert('แก้ไขข้อมูลเรียบร้อยแล้ว');";
			echo "window.location ='bank.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='bank.php'; ";
			echo "</script>";
		}
?>