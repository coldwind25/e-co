<?php 
include 'header.php';
include 'menu_left.php';

@$act = $_GET['act'];


if($act == 'add'){
  include 'prdtype_form_add.php';
}elseif($act == 'edit'){
  include 'prdtype_form_edit.php';
}else{
  include 'prdtype_list.php';
}




include 'footer.php';
?>
