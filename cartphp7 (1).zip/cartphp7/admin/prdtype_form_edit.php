
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<?php 
$t_id = mysqli_real_escape_string($condb,$_GET['t_id']);
$queryprdtype = "SELECT * FROM tbl_type WHERE t_id=$t_id" 
or die ("Error : ".mysqli_error($queryprdtype));
$rsprdtype = mysqli_query($condb, $queryprdtype);
$row = mysqli_fetch_array($rsprdtype);
//print_r($row);
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
  ฟอร์มแก้ไขข้อมูลประเภทสินค้า
  </h1>
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-xs-7">
      <div class="box">
        <!-- /.box-header -->
        <div class="box-body">
          <form action="prdtype_form_edit_db.php" method="post" class="form-horizontal" enctype="multipart/form-data">
            <div class="form-group">
              <div class="col-sm-2 control-label">
                ประเภทสินค้า
              </div>
              <div class="col-sm-4">
                <input type="text" name="t_name" class="form-control" required minlength="3" placeholder="ประเภทสินค้า" value="<?php echo $row['t_name'];?>">
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-2 control-label">
              </div>
              <div class="col-sm-4">
                <input type="hidden" name="t_id" value="<?php echo $row['t_id'];?>">
                <button type="submit" class="btn btn-primary"> SAVE </button>
              </div>
            </div>
          </form>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->