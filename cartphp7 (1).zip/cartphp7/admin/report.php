<?php 
include 'header.php';
include 'menu_left.php';


@$act = $_GET['act'];



if($act=='m'){
	include 'report_list_month.php';
}elseif ($act=='y') {
	include 'report_list_year.php';
}elseif ($act=='top5') {
	include 'report_list_top5.php';
}elseif ($act=='topsale') {
	include 'report_list_top5_by_price.php';
}elseif ($act=='range') {
	include 'report_list_range.php';
}elseif ($act=='rdate') {
	include 'report_list_range_by_date.php';
}else{
	include 'report_list_day.php';
}






include 'footer.php';
?>
