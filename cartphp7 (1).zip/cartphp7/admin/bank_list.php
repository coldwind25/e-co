<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<?php 
$querybank = "SELECT * FROM tbl_bank" 
or die ("Error : ".mysqli_error($querybank));
$rsbank = mysqli_query($condb, $querybank);
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
  จัดการธนาคาร
  <a href="bank.php?act=add" class="btn btn-primary"> +เพิ่มข้อมูล </a>
<!--   <small>advanced tables</small> -->
  </h1>
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">รายการธนาคาร </h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
              <tr class="danger">
                <th width="5%">ID</th>
                <th width="5%">Logo</th>
                <th width="15%">ประเภท</th>
                <th width="30%">ธนาคาร</th>
                <th width="15%">เลข บ/ช</th>
                <th width="15%">เจ้าของ</th>
                <th width="5%">แก้ไข</th>
                <th width="5%">ลบ</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rsbank as $row) { ?>
              <tr>
                <td><?php echo @$i+=1; ?></td>
                <td> <img src="../bank_logo/<?php echo $row['b_logo'];?>" width="100%"> </td>
                <td><?php echo $row['b_type'];?></td>
                <td><?php echo $row['b_name'];?></td>
                <td><?php echo $row['b_number'];?></td>
                <td><?php echo $row['b_owner'];?></td>
                <td align="center">
                  <a href="bank.php?act=edit&b_id=<?php echo $row['b_id'];?>" class="btn btn-warning btn-xs"> แก้ไข </a></td>
                <td align="center">
                  <a href="bank_del.php?b_id=<?php echo $row['b_id'];?>" class="btn btn-danger btn-xs" onclick="return confirm('ยืนยันการลบข้อมูล');"> ลบ </a></td>
              </tr>
            <?php } ?>
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->