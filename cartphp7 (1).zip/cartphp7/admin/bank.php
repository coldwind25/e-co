<?php 
include 'header.php';
include 'menu_left.php';

@$act = $_GET['act'];


if($act == 'add'){
  include 'bank_form_add.php';
}elseif($act == 'edit'){
  include 'bank_form_edit.php';
}else{
  include 'bank_list.php';
}




include 'footer.php';
?>
