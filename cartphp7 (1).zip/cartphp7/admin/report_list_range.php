
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">

<?php 
$queryorder = "
SELECT SUM(pay_amount) AS total, 
DATE_FORMAT(order_date, '%d-%m-%Y') AS datesave
FROM tbl_order
WHERE order_status > 1
GROUP BY DATE_FORMAT(order_date, '%d-%m-%Y')" 
or die ("Error : ".mysqli_error($queryorder));
$rsorder = mysqli_query($condb, $queryorder);

//echo $queryorder;
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
 รายงานแยกตามวัน (เลือกช่วงวันที่)
  <button class="btn btn-primary" onclick="window.print();">พิมพ์รายงาน</button>
  </h1>
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-xs-8">
      <div class="box">
        <div class="box-header">
          <h3>เรียกดูรายงาน</h3>

          <form action="" method="get" class="form-horizontal">

            <div class="form-group">
              <div class="col-xs-1 control-label">
                Start
              </div>
              <div class="col-xs-3">
                <input type="date" name="ds" required class="form-control">
              </div>
              <div class="col-xs-1 control-label">
                End
              </div>
              <div class="col-xs-3">
                <input type="date" name="de" required class="form-control">
              </div>
              <div class="col-xs-1">
                 <button type="submit"  name="act" value="rdate" class="btn btn-primary">เรียกดู</button>
              </div>
            </div>
            
          </form>


          <h3 class="box-title">รายการสั่งซื้อแยกตามวัน</h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
              <tr class="danger">
                <th width="50%">ว/ด/ป</th>
                <th width="50%"><center>ยอดขาย</center></th>
              </tr>
            </thead>
            <tbody>
              <?php

               foreach ($rsorder as $row) { ?>
              <tr>
                <td><?php echo $row['datesave'];?></td>
                <td align="right"><?php echo number_format($row['total'],2);?> บาท </td>
              </tr>  
              <?php @$ototal += $row['total']; } ?> 
              <tr class="danger">
                <td>รวมยอดขาย</td>
                <td align="right">
                  <b>
                    <font color="red">
                  <?php echo number_format(@$ototal,2);?> บาท
                </font>
              </b>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->