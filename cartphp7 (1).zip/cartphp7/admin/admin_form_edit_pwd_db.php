<meta charset=utf-8>
<?php 
include('../condb.php');
// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
// exit;

//ประกาศตัวแปรรับค่าจากฟอร์ม 
$admin_pass = mysqli_real_escape_string($condb,sha1($_POST['admin_pass']));
$admin_id = mysqli_real_escape_string($condb,$_POST['admin_id']);

		//นำเข้าตารางเก็บข้อมูล
		$sql ="UPDATE tbl_admin SET 
	 
		admin_pass='$admin_pass'

		WHERE admin_id = $admin_id

		";

		$result = mysqli_query($condb, $sql) or die("Error : $sql". mysqli_error());


// echo $sql;
// exit;

mysqli_close($condb);

if($result){
			echo "<script>";
			echo "alert('แก้ไขรหัสผ่าน admin เรียบร้อยแล้ว');";
			echo "window.location ='admin.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='admin.php'; ";
			echo "</script>";
		}


?>