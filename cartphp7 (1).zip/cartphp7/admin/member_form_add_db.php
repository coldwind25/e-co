<meta charset="UTF-8" />
<?php
include('../condb.php');

	$date1 = date("Ymd_His");
	//สร้างตัวแปรสุ่มตัวเลขเพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลดไม่ให้ชื่อไฟล์ซ้ำกัน
	$numrand = (mt_rand());


$mem_username = mysqli_real_escape_string($condb,$_POST['mem_username']);
$mem_password = mysqli_real_escape_string($condb,sha1($_POST['mem_password']));
$mem_name = mysqli_real_escape_string($condb,$_POST['mem_name']);
$mem_email = mysqli_real_escape_string($condb,$_POST['mem_email']);
$mem_tel = mysqli_real_escape_string($condb,$_POST['mem_tel']);
$mem_address = mysqli_real_escape_string($condb,$_POST['mem_address']);

$check ="SELECT * FROM tbl_member  WHERE mem_username='$mem_username'";
$result1=mysqli_query($condb, $check);
$num=mysqli_num_rows($result1);

if($num > 0)
{
			echo "<script>";
			echo "alert('ข้อมูลซ้ำ');";
			echo "window.location ='member.php'; ";
			echo "</script>";
} else {


//upload ภาพ 
	$upload=$_FILES['mem_img'];
	if($upload !='') { 
 
	//โฟลเดอร์ที่เก็บไฟล์
	$path="../mem_img/";
	//ตัวขื่อกับนามสกุลภาพออกจากกัน
	$type = strrchr($_FILES['mem_img']['name'],".");
	//ตั้งชื่อไฟล์ใหม่เป็น สุ่มตัวเลข+วันที่
	$newname ='member'.$numrand.$date1.$type;
	$path_copy=$path.$newname;
	$path_link="../mem_img/".$newname;
	//คัดลอกไฟล์ไปยังโฟลเดอร์
	move_uploaded_file($_FILES['mem_img']['tmp_name'],$path_copy);  
		
	}else{}



$sql ="INSERT INTO tbl_member
		(
		mem_username,
		mem_password,
		mem_name,
		mem_email,
		mem_tel,
		mem_address,
		mem_img
		)
		VALUES
		(
		'$mem_username',
		'$mem_password',
		'$mem_name',
		'$mem_email',
		'$mem_tel',
		'$mem_address',
		'$newname'
	)";
		
		$result = mysqli_query($condb, $sql) or die("Error in query : $sql" .mysqli_error());
}

		mysqli_close($condb);
		
		if($result){
			echo "<script>";
			echo "alert('เพิ่มสมาชิกเรียบร้อยแล้ว');";
			echo "window.location ='member.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='member.php'; ";
			echo "</script>";
		}
		
?>