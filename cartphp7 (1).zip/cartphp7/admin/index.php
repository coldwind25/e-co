<?php 
include 'header.php';
include 'menu_left.php';


@$act = $_GET['act'];
if($act=='detail'){
	include 'order_status1.php';
}elseif ($act=='cancel') {
	include 'order_cancel.php';
}elseif ($act=='paid') {
	include 'list_status2.php';
}elseif ($act=='ems') {
	include 'order_status2.php';
}elseif ($act=='complete') {
	include 'list_status3.php';
}elseif ($act=='close') {
	include 'order_status3.php';
}elseif ($act=='cancelorder') {
	include 'list_status4.php';
}else{
	include 'list_status1.php';
}




include 'footer.php';
?>
