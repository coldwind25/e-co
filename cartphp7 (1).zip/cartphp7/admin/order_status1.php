
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <?php
$order_id = mysqli_real_escape_string($condb,$_GET['order_id']);
$qorder = "
SELECT o.*,d.*,p.*,m.*
FROM tbl_order as o
INNER JOIN  tbl_order_detail as d ON o.order_id = d.order_id
INNER JOIN tbl_product as p ON d.p_id = p.p_id
INNER JOIN tbl_member as m ON o.mem_id = m.mem_id
WHERE  o.order_id=$order_id
"
or die ("Error : ".mysqli_error($qorder));
$rsorder = mysqli_query($condb, $qorder);
$rsbill = mysqli_fetch_array($rsorder);

//print_r($rsbill);

// echo $qorder;
// exit;
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
   รายละเอียดการสั่งซื้อ
<!--   <small>advanced tables</small> -->
  </h1>
</section>
<!-- Main content -->

<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title"> รายการสั่งซื้อ (รอชำระเงิน) </h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
        <h4 align="center"> 
          OrderID : <?php echo $_GET['order_id'];?>
          <br>
          ว/ด/ป : <?php echo $rsbill['order_date'];?>
          <br>
          ลูกค้า : <?php echo $rsbill['mem_name'];?>
          <br>
          ที่อยู่ : <?php echo $rsbill['mem_address'];?>
          <br>
          Email : <?php echo $rsbill['mem_email'];?>
          <br>
          Phone : <?php echo $rsbill['mem_tel'];?>
         </h4>
        <table class="table table-bordered table-striped">
          <tr>
            <td bgcolor="#EAEAEA" width="5%">#</td>
            <td bgcolor="#EAEAEA" width="5%">img</td>
            <td bgcolor="#EAEAEA" width="50%">ขื่อสินค้า</td>
            <td align="center" bgcolor="#EAEAEA" width="10%">ราคา</td>
            <td align="center" bgcolor="#EAEAEA" width="10%">จำนวน</td>
            <td align="center" bgcolor="#EAEAEA" width="10%">รวม(บาท)</td>
          </tr>
          <?php
          $total=0;
          foreach ($rsorder as $row) {
          $sum = $row['total']; //
          $total += $sum;
          $p_c_qty = $row['p_c_qty'];
          echo "<tr>";
            echo "<td>" . @$i += 1 . "</td>";
            echo "<td>"
              . "<img src='../product_img/".$row['p_img']."' width='100%'>"
            . "</td>";
            echo "<td>" . $row["p_name"] . "</td>";
            echo "<td align='right'>" .number_format($row["p_price"],2) . "</td>";
            echo "<td align='right'>";
              echo "<input type='number' name='p_c_qty' value='$p_c_qty' class='form-control' readonly /></td>";
              echo "<td align='right'>".number_format($sum,2)."</td>";
            echo "</tr>";
            }
            echo "<tr>";
              echo "<td colspan='5' bgcolor='#CEE7FF' align='center'><b>ราคารวม</b></td>";
              echo "<td align='right' bgcolor='#CEE7FF'>"."<b>".number_format($total,2)."</b>"."</td>";
            echo "</tr>";
            ?>
          </table>
          
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->