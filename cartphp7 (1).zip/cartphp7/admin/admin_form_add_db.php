<meta charset=utf-8>
<?php 
include('../condb.php');
// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
// exit;

//ประกาศตัวแปรรับค่าจากฟอร์ม 
$admin_user = mysqli_real_escape_string($condb,$_POST['admin_user']);
$admin_pass = mysqli_real_escape_string($condb,sha1($_POST['admin_pass']));
$admin_name = mysqli_real_escape_string($condb,$_POST['admin_name']);

//เช็ค user ซ้ำ 
$check ="SELECT * FROM tbl_admin  WHERE admin_user='$admin_user'";
$result1=mysqli_query($condb, $check);
$num=mysqli_num_rows($result1);

// echo $num;
// exit;

if($num > 0)
{
			echo "<script>";
			echo "alert('user นีมีผู้ใช้แล้ว กรุณาสมัครใหม่อีกครั้ง');";
			echo "window.location ='admin.php'; ";
			echo "</script>";
}else{
		//นำเข้าตารางเก็บข้อมูล
		$sql ="INSERT INTO tbl_admin
		(
		admin_user,
		admin_pass,
		admin_name
		)
		VALUES
		(
		'$admin_user',
		'$admin_pass',
		'$admin_name'
		)
		";

		$result = mysqli_query($condb, $sql) or die("Error : $sql". mysqli_error());

}

// echo $sql;
// exit;

mysqli_close($condb);

if($result){
			echo "<script>";
			echo "alert('เพิ่ม admin เรียบร้อยแล้ว');";
			echo "window.location ='admin.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='admin.php'; ";
			echo "</script>";
		}


?>