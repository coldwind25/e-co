<script src="ckeditor/ckeditor.js"></script>
<script src="ckeditor/samples/js/sample.js"></script>
<link rel="stylesheet" href="ckeditor/samples/toolbarconfigurator/lib/codemirror/neo.css">
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<?php 
$p_id = mysqli_real_escape_string($condb,$_GET['p_id']);
//query product
$queryproduct = "
SELECT p.*, t.t_name
FROM tbl_product as p 
INNER JOIN tbl_type as t ON p.t_id=t.t_id
WHERE p.p_id=$p_id
" 
or die ("Error : ".mysqli_error($queryproduct));
$rsproduct = mysqli_query($condb, $queryproduct);
$rs = mysqli_fetch_array($rsproduct);

// echo '<pre>';
// print_r($rs);
// echo '</pre>';
// exit;



//query type
$queryprdtype = "SELECT * FROM tbl_type" 
or die ("Error : ".mysqli_error($queryprdtype));
$rsprdtype = mysqli_query($condb, $queryprdtype);
?>
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
    ฟอร์มแก้ไขข้อมูลสินค้า
    </h1>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <!-- /.box-header -->
          <div class="box-body">
            <form action="product_form_edit_db.php" method="post" class="form-horizontal" enctype="multipart/form-data">
              <div class="form-group">
                <div class="col-sm-2 control-label">
                  Type
                </div>
                <div class="col-sm-4">
                  <select name="t_id" required class="form-control">
                    <option value="<?php echo $rs['t_id'];?>"><?php echo $rs['t_name'];?></option>
                    <option value="">เลือกข้อมูล</option>
                    <?php foreach ($rsprdtype as $row) { ?>
                    <option value="<?php echo $row['t_id'];?>"><?php echo $row['t_name'];?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-2 control-label">
                  Name
                </div>
                <div class="col-sm-4">
                  <input type="text" name="p_name" class="form-control" required minlength="3" placeholder="ชื่อ" value="<?php echo $rs['p_name'];?>">
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-2 control-label">
                  detail
                </div>
                <div class="col-sm-10">
                  <textarea name="p_detial" id="editor" cols="69" rows="4"><?php echo $rs['p_detial'];?></textarea>
                </div>
              </div>

              <div class="form-group">
                <div class="col-sm-2 control-label">
                  Price
                </div>
                <div class="col-sm-2">
                  <input type="number" name="p_price" class="form-control" required min="0" placeholder="price" value="<?php echo $rs['p_price'];?>">
                </div>
              </div>

              <div class="form-group">
                <div class="col-sm-2 control-label">
                  QTY
                </div>
                <div class="col-sm-2">
                  <input type="number" name="p_qty" class="form-control" required min="0" placeholder="p_qty" value="<?php echo $rs['p_qty'];?>">
                </div>
              </div>
              
              <div class="form-group">
                <div class="col-sm-2 control-label">
                  IMG
                </div>
                <div class="col-sm-4">
                  <img src="../product_img/<?php echo $rs['p_img'];?>" width="100%">
                  <br><br>
                  เลือกภาพใหม่ <br>
                  <input type="file" name="p_img"  accept="image/*" class="form-control">
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-2 control-label">
                </div>
                <div class="col-sm-4">
                  <input type="hidden" name="p_id" value="<?php echo $rs['p_id'];?>">
                  <input type="hidden" name="p_img2" value="<?php echo $rs['p_img'];?>">
                  <button type="submit" class="btn btn-primary"> SAVE </button>
                </div>
              </div>
            </form>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
<script>
initSample();
</script>