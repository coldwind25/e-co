<meta charset=utf-8>
<?php 
include('../condb.php');
// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
// exit;

//ประกาศตัวแปรรับค่าจากฟอร์ม 
$mem_id = mysqli_real_escape_string($condb,$_GET['mem_id']);

		//นำเข้าตารางเก็บข้อมูล
		$sql ="DELETE FROM  tbl_member WHERE mem_id = $mem_id ";

		$result = mysqli_query($condb, $sql) or die("Error : $sql". mysqli_error());


// echo $sql;
// exit;

mysqli_close($condb);

if($result){
			echo "<script>";
			//echo "alert('แก้ไขข้อมูล member เรียบร้อยแล้ว');";
			echo "window.location ='member.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='member.php'; ";
			echo "</script>";
		}


?>