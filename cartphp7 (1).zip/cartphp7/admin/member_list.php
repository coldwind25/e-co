<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<?php 
$querymember = "SELECT * FROM tbl_member" 
or die ("Error : ".mysqli_error($querymember));
$rsmember = mysqli_query($condb, $querymember);
?>
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
  จัดการสมาชิก
  <a href="member.php?act=add" class="btn btn-primary"> +เพิ่มข้อมูล </a>
<!--   <small>advanced tables</small> -->
  </h1>
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-xs-12">
      <div class="box">
        <div class="box-header">
          <h3 class="box-title">รายการ member </h3>
        </div>
        <!-- /.box-header -->
        <div class="box-body">
          <table id="example1" class="table table-bordered table-striped">
            <thead>
              <tr class="danger">
                <th width="5%">ID</th>
                <th width="5%">IMG</th>
                <th width="40%">NAME</th>
                <th width="10%">USER</th>
                <th width="10%">PHONE</th>
                <th width="10%">EMAIL</th>
                <th width="5%">แก้รหัส</th>
                <th width="5%">แก้ไข</th>
                <th width="5%">ลบ</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rsmember as $row) { ?>
              <tr>
                <td><?php echo @$i+=1; ?></td>
                <td> <img src="../mem_img/<?php echo $row['mem_img'];?>" width="50%"> </td>
                <td>
                  <b><?php echo $row['mem_name'];?></b>
                  <br>
                  ที่อยู่. <?php echo $row['mem_address'];?>
                </td>
                <td><?php echo $row['mem_username'];?></td>
                <td><?php echo $row['mem_tel'];?></td>
                <td><?php echo $row['mem_email'];?></td>
                <td align="center">
                  <a href="member.php?act=pwd&mem_id=<?php echo $row['mem_id'];?>" class="btn btn-info btn-xs"> แก้รหัส </a></td>
                <td align="center">
                  <a href="member.php?act=edit&mem_id=<?php echo $row['mem_id'];?>" class="btn btn-warning btn-xs"> แก้ไข </a></td>
                <td align="center">
                  <a href="member_del.php?mem_id=<?php echo $row['mem_id'];?>" class="btn btn-danger btn-xs" onclick="return confirm('ยืนยันการลบข้อมูล');"> ลบ </a></td>
              </tr>
            <?php } ?>
            </tbody>
          </table>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->