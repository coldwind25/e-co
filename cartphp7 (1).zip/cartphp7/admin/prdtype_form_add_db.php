<meta charset=utf-8>
<?php 
include('../condb.php');
// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
// exit;

//ประกาศตัวแปรรับค่าจากฟอร์ม 
$t_name = mysqli_real_escape_string($condb,$_POST['t_name']);

//เช็ค user ซ้ำ 
$check ="SELECT * FROM tbl_type  WHERE t_name='$t_name'";
$result1=mysqli_query($condb, $check);
$num=mysqli_num_rows($result1);

// echo $num;
// exit;

if($num > 0)
{
			echo "<script>";
			echo "alert('ข้อมูลซ้ำ');";
			echo "window.location ='prdtype.php'; ";
			echo "</script>";
}else{
		//นำเข้าตารางเก็บข้อมูล
		$sql ="INSERT INTO tbl_type
		(
		t_name
		)
		VALUES
		(
		'$t_name'
		)
		";

		$result = mysqli_query($condb, $sql) or die("Error : $sql". mysqli_error());

}

// echo $sql;
// exit;

mysqli_close($condb);

if($result){
			echo "<script>";
			echo "alert('เพิ่มข้อมูลเรียบร้อยแล้ว');";
			echo "window.location ='prdtype.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='prdtype.php'; ";
			echo "</script>";
		}


?>