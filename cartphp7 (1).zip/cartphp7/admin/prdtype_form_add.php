
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
<!-- Content Header (Page header) -->
<section class="content-header">
  <h1>
  ฟอร์มเพิ่มข้อมูลประเภทสินค้า
  </h1>
</section>
<!-- Main content -->
<section class="content">
  <div class="row">
    <div class="col-xs-7">
      <div class="box">
        <!-- /.box-header -->
        <div class="box-body">
          <form action="prdtype_form_add_db.php" method="post" class="form-horizontal" enctype="multipart/form-data">
            <div class="form-group">
              <div class="col-sm-2 control-label">
                ประเภทสินค้า
              </div>
              <div class="col-sm-4">
                <input type="text" name="t_name" class="form-control" required minlength="3" placeholder="ประเภทสินค้า">
              </div>
            </div>
            <div class="form-group">
              <div class="col-sm-2 control-label">
              </div>
              <div class="col-sm-4">
                <button type="submit" class="btn btn-primary"> SAVE </button>
              </div>
            </div>
          </form>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->