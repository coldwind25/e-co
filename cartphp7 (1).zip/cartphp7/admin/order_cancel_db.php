<meta charset=utf-8>
<?php 
include('../condb.php');

// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
//exit;


// if($_POST['submit']!='submit'){
// 	    echo "<script>";
// 	    echo "alert('เกิดข้อผิดพลาด กรุณาติดต่อผู้ดูแลระบบ !');";
// 	    echo "window.history.back();";
// 	    echo "</script>";
// }





foreach($_POST['p_id']  as $row=>$art){
$p_id = ($_POST['p_id'][$row]);
$returnstock = ($_POST['returnstock'][$row]);
//return stock
  $sql = "UPDATE tbl_product SET  
  	     p_qty=$returnstock
  WHERE  p_id=$p_id";
  $result = mysqli_query($condb, $sql) or die("Error : $sql". mysqli_error());


    // echo '<pre>';
    // print_r($sql);
    // echo '</pre>';

    }


//update status = 4
   $order_id = mysqli_real_escape_string($condb,$_POST['order_id']);

//นำเข้าตารางเก็บข้อมูล
		$sql2 ="UPDATE tbl_order SET
		order_status=4
		WHERE order_id=$order_id
		";
		$result2 = mysqli_query($condb, $sql2) or die("Error : $sql2". mysqli_error());


		//echo $sql2;
    
    //exit;

mysqli_close($condb);

if($result && $result2){
			echo "<script>";
			echo "alert('ยกเลิกและคืนสต๊อกเรียบร้อยแล้ว');";
			echo "window.location ='index.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='index.php'; ";
			echo "</script>";
		}


?>