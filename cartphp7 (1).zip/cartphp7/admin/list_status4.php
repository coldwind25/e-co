<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <?php
  $datenow = date('Y-m-d');
  $queryorder = "
  SELECT o.*, m.mem_name, m.mem_tel,
  DATEDIFF('$datenow' , DATE_FORMAT(o.order_date, '%Y-%m-%d')) as totaldate
  FROM tbl_order as o
  INNER JOIN tbl_member as m ON o.mem_id = m.mem_id
  WHERE o.order_status=4"
  or die ("Error : ".mysqli_error($queryorder));
  $rsorder = mysqli_query($condb, $queryorder);
  //echo $queryorder;
  ?>
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
    รายการสั่่งซื้อ
    <a href="index.php" class="btn btn-warning"> รอชำระเงิน </a>
    <a href="index.php?act=paid" class="btn btn-info"> ชำระเงินแล้ว </a>
    <a href="index.php?act=complete" class="btn btn-success"> แจ้ง EMS แล้ว </a>
     <a href="index.php?act=cancelorder" class="btn btn-danger"> ยกเลิก </a>
    </h1>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-12">
        <div class="box">
          <div class="box-header">
            <h3 class="box-title">รายการยกเลิกเนื่องจากไม่ชำระเงินภายใน 3 วัน </h3>
          </div>
          <!-- /.box-header -->
          <div class="box-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
                <tr class="danger">
                  <th width="5%">#</th>
                  <th width="20%">customer</th>
                  <th width="15%">status</th>
                  <th width="15%">date_order</th>
                  <th width="15%"><center>คำนวนวัน</center></th>
                  <th width="5%"><center>view</center></th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($rsorder as $row) { ?>
                <tr>
                  <td><?php echo $row['order_id'];?></td>
                  <td><?php
                    echo $row['mem_name']
                    .'phone : '.$row['mem_tel']
                  ;?></td>
                  <td>
                    <?php
                    $status = $row['order_status'];
                    include('status.php');
                    ?>
                    
                  </td>
                  <td><?php echo $row['order_date'];?></td>
                  <td align="center">
                    <?php
                    $totaldate = $row['totaldate'];
                    echo 'เกิน '.$totaldate .' วัน';
                    echo '<br>';
                    if($totaldate >= 3){
                    echo '<b><font color="red">';
                    echo '*ยกเลิกรายการแล้ว';
                    echo '</font></b>';
                    $st = 'canclecart&tdate='.$totaldate;
                    }
                    ?>
                    
                  </td>
                  <td align="center">
                     
                    <a href="index.php?order_id=<?php echo $row['order_id'];?>&act=detail" class="btn btn-info btn-xs" target="_blank"> view </a>
                 


                    
                  </td>
                
                </tr>
                <?php } ?>
              </tbody>
            </table>
          </div>
          <!-- /.box-body -->
        </div>
        <!-- /.box -->
      </div>
      <!-- /.col -->
    </div>
    <!-- /.row -->
  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->