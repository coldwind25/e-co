<meta charset="UTF-8" />
<?php
include('../condb.php');
 
	//สร้างตัวแปรวันที่เพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลด
	$date1 = date("Ymd_His");
	//สร้างตัวแปรสุ่มตัวเลขเพื่อเอาไปตั้งชื่อไฟล์ที่อัพโหลดไม่ให้ชื่อไฟล์ซ้ำกัน
	$numrand = (mt_rand());

$p_name = mysqli_real_escape_string($condb,$_POST['p_name']);
$t_id = mysqli_real_escape_string($condb,$_POST['t_id']);
$p_detial = mysqli_real_escape_string($condb,$_POST['p_detial']);
$p_price = mysqli_real_escape_string($condb,$_POST['p_price']);
$p_qty = mysqli_real_escape_string($condb,$_POST['p_qty']);

$p_img = (isset($_POST['p_img']) ? $_POST['p_img'] : '');
$upload=$_FILES['p_img'];
	if($upload !='') { 
	//โฟลเดอร์ที่เก็บไฟล์
	$path="../product_img/";
	//ตัวขื่อกับนามสกุลภาพออกจากกัน
	$type = strrchr($_FILES['p_img']['name'],".");
	//ตั้งชื่อไฟล์ใหม่เป็น สุ่มตัวเลข+วันที่
	$newname ='product'.$numrand.$date1.$type;
 
	$path_copy=$path.$newname;
	$path_link="../product_img/".$newname;
	//คัดลอกไฟล์ไปยังโฟลเดอร์
	move_uploaded_file($_FILES['p_img']['tmp_name'],$path_copy);  
		
	}else{}

 
$sql ="INSERT INTO tbl_product
		
		(
		p_name,
		t_id,
		p_detial,
		p_price,
		p_qty,
		p_img
		)
		
		VALUES
		(
		'$p_name',
		'$t_id',
		'$p_detial',
		'$p_price',
	 	'$p_qty',
		'$newname'	
		)";
		
		$result = mysqli_query($condb, $sql) or die("Error in query : $sql" .mysqli_error());
 
// echo $sql;
// exit();

		mysqli_close($condb);
		
		if($result){
			echo "<script>";
			echo "alert('เพิ่มสินค้าเรียบร้อยแล้ว');";
			echo "window.location ='product.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='product.php'; ";
			echo "</script>";
		}
		


?>