<meta charset=utf-8>
<?php 
include('../condb.php');
// echo '<pre>';
// print_r($_POST);
// echo '</pre>';
// exit;

//ประกาศตัวแปรรับค่าจากฟอร์ม 
$p_id = $_GET['p_id'];

		//นำเข้าตารางเก็บข้อมูล
		$sql ="DELETE FROM  tbl_product WHERE p_id = $p_id ";

		$result = mysqli_query($condb, $sql) or die("Error : $sql". mysqli_error());


// echo $sql;
// exit;

mysqli_close($condb);

if($result){
			echo "<script>";
			//echo "alert('แก้ไขข้อมูล product เรียบร้อยแล้ว');";
			echo "window.location ='product.php'; ";
			echo "</script>";
		} else {
			
			echo "<script>";
			echo "alert('ERROR!');";
			echo "window.location ='product.php'; ";
			echo "</script>";
		}


?>