<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
<!-- sidebar: style can be found in sidebar.less -->
<section class="sidebar">
  <!-- Sidebar user panel -->
  <div class="user-panel">
    <div class="pull-left image">
      <img src="../dist/img/user2-160x160.jpg" class="img-circle" alt="User Image">
    </div>
    <div class="pull-left info">
      <p><?php echo $admin_name;?></p>
      <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
    </div>
  </div>
  <!-- sidebar menu: : style can be found in sidebar.less -->
  <ul class="sidebar-menu" data-widget="tree">
    <li class="header">MAIN NAVIGATION</li>
    <li><a href="index.php"><i class="fa fa-home"></i> <span>หน้าหลัก</span></a></li>
    <li><a href="admin.php"><i class="fa fa-book"></i> <span>จัดการ Admin </span></a></li>
    <li><a href="member.php"><i class="fa fa-book"></i> <span>จัดการสมาชิก </span></a></li>
    <li><a href="prdtype.php"><i class="fa fa-book"></i> <span>จัดการประเภทสินค้า </span></a></li>
    <li><a href="product.php"><i class="fa fa-book"></i> <span>จัดการสินค้า </span></a></li>
    <li><a href="bank.php"><i class="fa fa-book"></i> <span>จัดการธนาคาร </span></a></li>
    <li><a href="report.php"><i class="fa fa-book"></i> <span>รายงาน-แยกตามวัน</span></a></li>
    <li><a href="report.php?act=m"><i class="fa fa-book"></i> <span>รายงาน-แยกตามเดือน</span></a></li>
    <li><a href="report.php?act=y"><i class="fa fa-book"></i> <span>รายงาน-แยกตามปี</span></a></li>
    <li><a href="report.php?act=top5"><i class="fa fa-book"></i> <span>รายงาน-ขายดี 5 อันดับ (จำนวน) </span></a></li>
    <li><a href="report.php?act=topsale"><i class="fa fa-book"></i> <span>รายงาน-ขายดี 5 อันดับ(ยอดขาย)</span></a></li>
    <li><a href="report.php?act=range"><i class="fa fa-book"></i> <span>รายงาน-เลือกช่วงวันที่</span></a></li>
  </ul>
</section>
<!-- /.sidebar -->
</aside>