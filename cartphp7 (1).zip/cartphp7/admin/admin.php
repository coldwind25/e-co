<?php 
include 'header.php';
include 'menu_left.php';

@$act = $_GET['act'];


if($act == 'add'){
  include 'admin_form_add.php';
}elseif($act == 'edit'){
  include 'admin_form_edit.php';
 }elseif($act == 'pwd'){
  include 'admin_form_edit_pwd.php';
}else{
  include 'admin_list.php';
}




include 'footer.php';
?>
