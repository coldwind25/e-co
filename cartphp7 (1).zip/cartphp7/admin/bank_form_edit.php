<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <?php
  $b_id = mysqli_real_escape_string($condb,$_GET['b_id']);
  $querybank = "SELECT * FROM tbl_bank WHERE b_id=$b_id"
  or die ("Error : ".mysqli_error($querybank));
  $rsbank = mysqli_query($condb, $querybank);
  $row = mysqli_fetch_array($rsbank);
  //print_r($row);
  ?>
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <h1>
    ฟอร์มแก้ไขข้อมูลธนาคาร
    </h1>
  </section>
  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-xs-7">
        <div class="box">
          <!-- /.box-header -->
          <div class="box-body">
            <form action="bank_form_edit_db.php"  method="post" enctype="multipart/form-data" name="Add_Product" id="Add_Product" >
              <table width="100%" border="0" align="center" cellpadding="0" cellspacing="0">
                <tr>
                  <td colspan="3" align="center">&nbsp;</td>
                </tr>
                <tr>
                  <td width="129" align="right" valign="middle">ธนาคาร :</td>
                  <td width="471" colspan="2"><label for="b_type"></label>
                  <input name="b_name" type="text" required   size="60" value="<?php echo $row['b_name'];?>" /></td>
                </tr>
                <tr>
                  <td align="right" valign="middle">&nbsp;</td>
                  <td colspan="2">&nbsp;</td>
                </tr>
                <tr>
                  <td align="right" valign="middle">เลขบัญชี :</td>
                  <td colspan="2"><input name="b_number" type="text" required   size="60" value="<?php echo $row['b_number'];?>"/></td>
                </tr>
                <tr>
                  <td align="right" valign="top">&nbsp;</td>
                  <td colspan="2">&nbsp;</td>
                </tr>
                <tr>
                  <td align="right" valign="middle">ประเภท :</td>
                  <td colspan="2"><input name="b_type" type="text" required     size="40" value="<?php echo $row['b_type'];?>"/></td>
                </tr>
                <tr>
                  <td align="right" valign="middle">&nbsp;</td>
                  <td colspan="2">&nbsp;</td>
                </tr>
                <tr>
                  <td align="right" valign="middle">สาขา :</td>
                  <td colspan="2"><input name="bn_name" type="text" required  size="60" value="<?php echo $row['bn_name'];?>"/></td>
                </tr>
                <tr>
                  <td align="right" valign="middle">&nbsp;</td>
                  <td colspan="2">&nbsp;</td>
                </tr>
                <tr>
                  <td align="right" valign="middle">ชื่อเจ้าของ บ/ช :</td>
                  <td colspan="2"><input name="b_owner" type="text" required   size="60" value="<?php echo $row['b_owner'];?>"/></td>
                </tr>
                <tr>
                  <td align="right" valign="middle">&nbsp;</td>
                  <td colspan="2">&nbsp;</td>
                </tr>
                <tr>
                  <td align="right" valign="middle">Logo</td>
                  <td colspan="2"><label for="b_logo"></label>
                    <img src="../bank_logo/<?php echo $row['b_logo'];?>" width="100px">
                  <br><br>
                  เลือกภาพใหม่
                  <br><br>
                <input type="file" name="b_logo" id="b_logo" accept="image/*"></td>
              </tr>
              <tr>
                <td align="right" valign="middle">&nbsp;</td>
                <td colspan="2">&nbsp;</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td colspan="2">
                  <input type="hidden" name="b_id" value="<?php echo $row['b_id'];?>">
                   <input type="hidden" name="b_logo2" value="<?php echo $row['b_logo'];?>">
                <button type="submit" name="button" id="button" class="btn btn-primary">บันทึก</button></td>
              </tr>
            </table>
          </form>
        </div>
        <!-- /.box-body -->
      </div>
      <!-- /.box -->
    </div>
    <!-- /.col -->
  </div>
  <!-- /.row -->
</section>
<!-- /.content -->
</div>
<!-- /.content-wrapper -->