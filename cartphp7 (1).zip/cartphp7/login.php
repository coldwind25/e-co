<?php
include('condb.php');
include 'header.php';
include 'banner.php';
include 'navbar.php';
 ?>
<title>Form Login</title>
<div class="container">
  <div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-4">
      <h4>Login Member</h4>
      <form name="frmlogin"  method="post" action="loginmember.php" class="form-horizontal">
        <p> </p>
        <p> ชื่อผู้ใช้ :
          <input type="text"   required name="mem_username" placeholder="Username" class="form-control">
        </p>
        <p>รหัสผ่าน :
          <input type="password"  required name="mem_password" placeholder="Password" class="form-control">
        </p>
        <p>
          <button type="submit" class="btn btn-primary">Login</button>
          &nbsp;&nbsp;
          <button type="reset" class="btn btn-danger">Reset</button>
          <br>
        </p>
      </form>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>