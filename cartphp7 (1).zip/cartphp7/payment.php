<?php
include 'header.php';
include 'navbar.php';
$order_id = mysqli_real_escape_string($condb,$_GET['order_id']);
$qorder = "
SELECT o.*,d.*,p.*
FROM tbl_order as o
INNER JOIN  tbl_order_detail as d ON o.order_id = d.order_id
INNER JOIN tbl_product as p ON d.p_id = p.p_id
WHERE  o.order_id=$order_id
"
or die ("Error : ".mysqli_error($qorder));
$rsorder = mysqli_query($condb, $qorder);
// echo $qorder;
// exit;
$querybank = "SELECT * FROM tbl_bank"
or die ("Error : ".mysqli_error($querybank));
$rsbank = mysqli_query($condb, $querybank);
?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h4>Payment</h4>
      <form id="frmcart" name="frmcart" method="post" action="payment_db.php" class="form-horizontal" enctype="multipart/form-data">
        <table class="table table-bordered table-striped">
          <tr>
            <td bgcolor="#EAEAEA" width="5%">#</td>
            <td bgcolor="#EAEAEA" width="5%">img</td>
            <td bgcolor="#EAEAEA" width="50%">ขื่อสินค้า</td>
            <td align="center" bgcolor="#EAEAEA" width="10%">ราคา</td>
            <td align="center" bgcolor="#EAEAEA" width="10%">จำนวน</td>
            <td align="center" bgcolor="#EAEAEA" width="10%">รวม(บาท)</td>
          </tr>
          <?php
          $total=0;
          foreach ($rsorder as $row) {
          $sum = $row['total']; //
          $total += $sum;
          $p_c_qty = $row['p_c_qty'];
          echo "<tr>";
            echo "<td>" . @$i += 1 . "</td>";
            echo "<td>"
              . "<img src='product_img/".$row['p_img']."' width='100%'>'"
            . "</td>";
            echo "<td>" . $row["p_name"] . "</td>";
            echo "<td align='right'>" .number_format($row["p_price"],2) . "</td>";
            echo "<td align='right'>";
              echo "<input type='number' name='p_c_qty' value='$p_c_qty' class='form-control' readonly /></td>";
              echo "<td align='right'>".number_format($sum,2)."</td>";
            echo "</tr>";
            }
            echo "<tr>";
              echo "<td colspan='5' bgcolor='#CEE7FF' align='center'><b>ราคารวม</b></td>";
              echo "<td align='right' bgcolor='#CEE7FF'>"."<b>".number_format($total,2)."</b>"."</td>";
            echo "</tr>";
            ?>
          </table>
          <h4>ชำระเงิน</h4>
          <b>เลือกธนาคารสำหรับแจ้งชำระเงิน</b>
          <table id="example1" class="table table-bordered table-striped table-responsive">
            <thead>
              <tr class="danger">
                <th width="5%">ID</th>
                <th width="5%" class="hidden-xs">IMG</th>
                <th width="15%" class="hidden-xs">Type</th>
                <th width="30%">NAME</th>
                <th width="15%">Number</th>
                <th width="15%">Owner</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($rsbank as $row) { ?>
              <tr>
                <td>
                  <input type="radio" name="b_id" value="<?php echo $row['b_id'];?>" required>
                </td>
                <td class="hidden-xs"> <img src="bank_logo/<?php echo $row['b_logo'];?>" width="100%"> </td>
                <td class="hidden-xs"><?php echo $row['b_type'];?></td>
                <td><?php echo $row['b_name'];?></td>
                <td><?php echo $row['b_number'];?></td>
                <td><?php echo $row['b_owner'];?></td>
              </tr>
              <?php } ?>
            </tbody>
          </table>
          
          <div class="form-group">
            <div class="col-md-4">
              <b> วันที่ชำระ </b>
              <input type="date" name="pay_date"  class="form-control" required>
            </div>
            
            <div class="col-md-2">
              <b> จำนวนที่ชำระ  </b>
              <input type="number" name="pay_amount"  any class="form-control" value="<?php echo $total;?>" required>
            </div>
          </div>

          <div class="form-group">
            <div class="col-md-4">
              <b> upload slip </b>
              <input type="file" name="pay_slip"  class="form-control" accept="image/*" required>
            </div>
          </div>


          <div class="form-group">
            <div class="col-md-4">
              <input type="hidden" name="order_id" value="<?php echo $order_id;?>">
              <button type="submit" class="btn btn-primary"> บันทึกการชำระเงิน </button>
            </div>
          </div>

        </form>
      </div>
    </div>
  </div>
  
  <?php include 'footer.php';?>