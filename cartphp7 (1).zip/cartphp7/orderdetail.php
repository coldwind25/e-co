<?php
include 'header.php';
include 'navbar.php';
$order_id = mysqli_real_escape_string($condb,$_GET['order_id']);
$qorder = "
SELECT o.*,d.*,p.*,b.*
FROM tbl_order as o
INNER JOIN  tbl_order_detail as d ON o.order_id = d.order_id
INNER JOIN tbl_product as p ON d.p_id = p.p_id
INNER JOIN tbl_bank as b ON o.b_id = b.b_id
WHERE  o.order_id=$order_id
"
or die ("Error : ".mysqli_error($qorder));
$rsorder = mysqli_query($condb, $qorder);
$rsbill = mysqli_fetch_array($rsorder);

//print_r($rsbill);

// echo $qorder;
// exit;
$querybank = "SELECT * FROM tbl_bank"
or die ("Error : ".mysqli_error($querybank));
$rsbank = mysqli_query($condb, $querybank);
?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h4>Payment</h4>
      
        <table class="table table-bordered table-striped">
          <tr>
            <td bgcolor="#EAEAEA" width="5%">#</td>
            <td bgcolor="#EAEAEA" width="5%">img</td>
            <td bgcolor="#EAEAEA" width="50%">ขื่อสินค้า</td>
            <td align="center" bgcolor="#EAEAEA" width="10%">ราคา</td>
            <td align="center" bgcolor="#EAEAEA" width="10%">จำนวน</td>
            <td align="center" bgcolor="#EAEAEA" width="10%">รวม(บาท)</td>
          </tr>
          <?php
          $total=0;
          foreach ($rsorder as $row) {
          $sum = $row['total']; //
          $total += $sum;
          $p_c_qty = $row['p_c_qty'];
          echo "<tr>";
            echo "<td>" . @$i += 1 . "</td>";
            echo "<td>"
              . "<img src='product_img/".$row['p_img']."' width='100%'>"
            . "</td>";
            echo "<td>" . $row["p_name"] . "</td>";
            echo "<td align='right'>" .number_format($row["p_price"],2) . "</td>";
            echo "<td align='right'>";
              echo "<input type='number' name='p_c_qty' value='$p_c_qty' class='form-control' readonly /></td>";
              echo "<td align='right'>".number_format($sum,2)."</td>";
            echo "</tr>";
            }
            echo "<tr>";
              echo "<td colspan='5' bgcolor='#CEE7FF' align='center'><b>ราคารวม</b></td>";
              echo "<td align='right' bgcolor='#CEE7FF'>"."<b>".number_format($total,2)."</b>"."</td>";
            echo "</tr>";
            ?>
          </table>
          <div class="col-xs-6">
          <h4>รายละเอียดการชำระเงิน</h4>
          <h4> slip : ว/ด/ป ที่ชำระ : <?php echo $rsbill['pay_date'];?>
            <br> ธนาคารที่โอนเงิน : <?php echo $rsbill['b_name'];?>
            <br> เลขบัญชี : <?php echo $rsbill['b_number'];?>
          </h4>
          <br>
          <img src="slip_img/<?php echo $rsbill['pay_slip'];?>" width="400px">
        </div>
        <div class="col-xs-6">
          <h2>ตรวจสอบเลข EMS  : 
          <?php
           @$act = $_GET['act'];
           if($act=='ems'){
            echo "<b><font color='red'>";
            echo $rsbill['postcode'];
            echo "</font></b>";
          ?>
          </h2>
          <br>
          <h4>
          <a href="https://track.thailandpost.co.th/" target="_blank"> **ตรวจสอบที่เว็บไปรษณีย์ </a>
        </h4>



         <?php   }else{
            echo '-';
           }
           ?>
        </div>
          </div>
        </div>
      </div>
  
  <?php include 'footer.php';?>