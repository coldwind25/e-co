<?php 
session_start();
        if(isset($_POST['mem_username'])){
				//connection
                  include("condb.php");
				//รับค่า user & mem_password
                  $mem_username = mysqli_real_escape_string($condb,$_POST['mem_username']);
                  $mem_password = mysqli_real_escape_string($condb,sha1($_POST['mem_password']));
				//query 
                  $sql="SELECT * FROM tbl_member 
                  WHERE mem_username='".$mem_username."' 
                  AND  mem_password='".$mem_password."' ";

                  $result = mysqli_query($condb,$sql);
				
                  if(mysqli_num_rows($result)==1){
                      $row = mysqli_fetch_array($result);
                     
                      $_SESSION["mem_id"] = $row["mem_id"];
                      $_SESSION["mem_name"] = $row["mem_name"];
                      $_SESSION["mem_img"] = $row["mem_img"];

                      // print_r($_SESSION);
                      // exit;


                      if($_SESSION["mem_id"] !=''){
                          Header("Location: member/");
                      }else{
                        echo "<script>";
                        echo "alert(\" user หรือ password ไม่ถูกต้อง\");"; 
                        echo "window.history.back()";
                        echo "</script>";
                      }


                  }else{
                    echo "<script>";
                        echo "alert(\" user หรือ  password ไม่ถูกต้อง\");"; 
                        echo "window.history.back()";
                    echo "</script>";

                  }

        }else{


                  echo "<script>";
                        echo "alert(\" user หรือ  password ไม่ถูกต้อง\");"; 
                        echo "window.history.back()";
                    echo "</script>";

        }
?>