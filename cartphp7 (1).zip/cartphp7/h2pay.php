<?php
include('condb.php');
include 'header.php';
include 'banner.php';
include 'navbar.php';
?>
<div class="container">
  <div class="row">
    <div class="col-md-12">
      <h3>วิธีชำระเงิน</h3>
       <pre>
       	วิธีชำระเงิน
       	วิธีชำระเงิน
       	วิธีชำระเงิน
       	วิธีชำระเงิน
       	วิธีชำระเงิน
       	วิธีชำระเงิน
       	วิธีชำระเงิน
        วิธีชำระเงิน
        วิธีชำระเงิน
        วิธีชำระเงิน
        วิธีชำระเงิน
        วิธีชำระเงิน
       </pre>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>