<?php 
session_start();
        if(isset($_POST['admin_user'])){
				//connection
                  include("condb.php");
				//รับค่า user & admin_pass
                  $admin_user = mysqli_real_escape_string($condb,$_POST['admin_user']);
                  $admin_pass = mysqli_real_escape_string($condb,sha1($_POST['admin_pass']));
				//query 
                  $sql="SELECT * FROM tbl_admin 
                  WHERE admin_user='".$admin_user."' 
                  AND  admin_pass='".$admin_pass."' ";

                  $result = mysqli_query($condb,$sql);
				
                  if(mysqli_num_rows($result)==1){
                      $row = mysqli_fetch_array($result);
                     
                      $_SESSION["admin_id"] = $row["admin_id"];
                      $_SESSION["admin_name"] = $row["admin_name"];

                      // print_r($_SESSION);
                      // exit;


                      if($_SESSION["admin_id"] !=''){
                          Header("Location: admin/");
                      }else{
                        echo "<script>";
                        echo "alert(\" user หรือ password ไม่ถูกต้อง\");"; 
                        echo "window.history.back()";
                        echo "</script>";
                      }


                  }else{
                    echo "<script>";
                        echo "alert(\" user หรือ  password ไม่ถูกต้อง\");"; 
                        echo "window.history.back()";
                    echo "</script>";

                  }

        }else{


                  echo "<script>";
                        echo "alert(\" user หรือ  password ไม่ถูกต้อง\");"; 
                        echo "window.history.back()";
                    echo "</script>";

        }
?>