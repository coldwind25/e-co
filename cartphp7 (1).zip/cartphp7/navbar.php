<div class="container">
  <div class="row">
    <div class="col-md-12">
      <nav class="navbar navbar-default">
        <div class="container-fluid">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="index.php"> <span class="glyphicon glyphicon-shopping-cart"></span> MySHOP</a>
          </div>
          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav">
              <li><a href="index.php"> <span class="glyphicon  glyphicon-home"></span> หน้าหลัก </a></li>
              
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">  <span class="glyphicon  glyphicon-list"></span> เกี่ยวกับ <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  
                  <li><a href="about.php">เกี่ยวกับร้านค้า</a></li>
                  <li><a href="h2buy.php">วิธีสั่งซื้อ</a></li>
                  <li><a href="h2pay.php">วิธีชำระเงิน</a></li>
                  
                </ul>
              </li>
              
              
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> <span class="glyphicon  glyphicon-list"></span> ประเภทสินค้า <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <?php foreach ($rsprdtype as $rst) { ?>
                  <li>
                    <a href="type.php?t_id=<?php echo $rst['t_id'];?>&show=แสดงสินค้าตามประเภท&name=<?php echo $rst['t_name'];?>">
                      <?php echo $rst['t_name'];?>
                    </a></li>
                    <?php } ?>
                  </ul>
                </li>
              </ul>
              <form action="q.php" class="navbar-form navbar-left">
                <div class="form-group">
                  <input type="text" name="q" class="form-control" placeholder="Search" required>
                </div>
                <button type="submit" class="btn btn-success">ค้นหา</button>
              </form>
              
              <ul class="nav navbar-nav navbar-right">
                
                <?php
                if($mem_id !=''){
                echo '<li><a href="cart.php"> <span class="glyphicon  glyphicon-shopping-cart"></span> ตะกร้าของฉัน</a></li>';
                echo
                '<li><a href="member/">'
                  .'<span class="glyphicon glyphicon-user"></span> '
                  .'คุณ'.$_SESSION['mem_name']
                .'</a></li>';
                echo '<li><a href="logout.php"> <span class="glyphicon glyphicon-log-out"></span> Logout</a></li>';
                }else{
                echo '<li><a href="register.php"><span class="glyphicon glyphicon-user"></span> สมัครสมาชิก</a></li>';
                echo '<li><a href="login.php"> <span class="glyphicon  glyphicon-log-in"></span> Login</a></li>';
                }
                ?>
                
              </ul>
              </div><!-- /.navbar-collapse -->
              </div><!-- /.container-fluid -->
            </nav>
          </div>
        </div>
      </div>


      